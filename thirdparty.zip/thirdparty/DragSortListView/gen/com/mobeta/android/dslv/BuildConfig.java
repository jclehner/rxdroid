/** Automatically generated file. DO NOT MODIFY */
package com.mobeta.android.dslv;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}