package com.github.espiandev.showcaseview;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ShowcaseViewTests {

    @Before
    public void setup() {

    }

    public void testSetOnShowcaseViewListenerIsSet() {

    }

}
